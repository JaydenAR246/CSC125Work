function countVowelsAndConsonants(text) {
let vowels = 0;
let consonants = 0;
text = text.toLowerCase();
for (let i = 0; i < text.length; i++) {
let char = text[i];
if (char === 'a' || char === 'e' || char === 'i' || char === 'o' || char === 'u') {
vowels++;
} else if (char >= 'a' && char <= 'z') {
consonants++;
}
}
return { vowels: vowels, consonants: consonants };
}

document.getElementById('analyze-btn').addEventListener('click', function() {
let text = document.getElementById('text-input').value;
if (text.trim() === '') {
alert('Please enter some text.');
return;
}
let result = countVowelsAndConsonants(text);
document.getElementById('vowels-count').textContent = result.vowels;
document.getElementById('consonants-count').textContent = result.consonants;
});

document.getElementById('calculate-bmi-btn').addEventListener('click', function() {
let weight = parseFloat(document.getElementById('weight').value);
let heightFeet = parseFloat(document.getElementById('height-feet').value);
let heightInches = parseFloat(document.getElementById('height-inches').value);
if (isNaN(weight) || isNaN(heightFeet) || isNaN(heightInches) || weight <= 0 || heightFeet < 0 || heightInches < 0) {
alert('Please enter valid positive numbers for weight and height.');
return;
}
let totalHeightInches = heightFeet * 12 + heightInches;
let bmi = (weight / (totalHeightInches * totalHeightInches)) * 703;
document.getElementById('bmi-value').textContent = bmi.toFixed(2);
});