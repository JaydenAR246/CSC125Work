const input = document.getElementById('textInput');
const button = document.getElementById('reverseButton');
const output = document.getElementById('output');

function reverseString(text) {
  return text.split('').reverse().join('');
}

button.addEventListener('click', () => {
  const value = input.value.trim();
  if (value === '') {
    output.textContent = 'Please enter some text.';
    return;
  }

  output.textContent = reverseString(value);
});
