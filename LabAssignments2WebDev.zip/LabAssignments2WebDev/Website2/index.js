function isPalindrome() {
    var n = document.getElementById('num').value;
    var r = n.split('').reverse().join('');
    document.getElementById('res').innerHTML = n === r ? 'Palindrome' : 'Not';
}