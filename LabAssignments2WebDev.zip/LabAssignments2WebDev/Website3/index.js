function calculate() {
    const subtotal = parseFloat(document.getElementById('subtotal').value);
    const tipPercent = parseFloat(document.getElementById('tip').value);
    if (isNaN(subtotal) || isNaN(tipPercent)) {
        alert('Please enter valid numbers');
        return;
    }
    const tip = subtotal * (tipPercent / 100);
    const total = subtotal + tip;
    document.getElementById('total').textContent = `Total: $${total.toFixed(2)}`;
}